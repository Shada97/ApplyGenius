# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.1].define(version: 2026_03_28_031952) do
  create_table "application_skills", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.integer "job_application_id", null: false
    t.integer "skill_id", null: false
    t.datetime "updated_at", null: false
    t.index ["job_application_id"], name: "index_application_skills_on_job_application_id"
    t.index ["skill_id"], name: "index_application_skills_on_skill_id"
  end

  create_table "companies", force: :cascade do |t|
    t.string "company_name"
    t.datetime "created_at", null: false
    t.string "industry"
    t.string "location"
    t.datetime "updated_at", null: false
    t.integer "user_id"
    t.string "website"
    t.index ["user_id"], name: "index_companies_on_user_id"
  end

  create_table "interviews", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.date "interview_date"
    t.string "interview_type"
    t.integer "job_application_id", null: false
    t.text "notes"
    t.datetime "updated_at", null: false
    t.index ["job_application_id"], name: "index_interviews_on_job_application_id"
  end

  create_table "job_applications", force: :cascade do |t|
    t.date "application_date"
    t.integer "company_id", null: false
    t.datetime "created_at", null: false
    t.string "job_title"
    t.string "status"
    t.datetime "updated_at", null: false
    t.integer "user_id", null: false
    t.index ["company_id"], name: "index_job_applications_on_company_id"
    t.index ["user_id"], name: "index_job_applications_on_user_id"
  end

  create_table "profiles", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "full_name"
    t.string "linkedin"
    t.string "resume"
    t.datetime "updated_at", null: false
    t.integer "user_id", null: false
    t.index ["user_id"], name: "index_profiles_on_user_id"
  end

  create_table "skills", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "name"
    t.datetime "updated_at", null: false
  end

  create_table "users", force: :cascade do |t|
    t.string "authentication_token"
    t.datetime "created_at", null: false
    t.string "email"
    t.string "encrypted_password", default: "", null: false
    t.string "password_digest"
    t.datetime "remember_created_at"
    t.datetime "reset_password_sent_at"
    t.string "reset_password_token"
    t.datetime "updated_at", null: false
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
  end

  add_foreign_key "application_skills", "job_applications"
  add_foreign_key "application_skills", "skills"
  add_foreign_key "companies", "users"
  add_foreign_key "interviews", "job_applications"
  add_foreign_key "job_applications", "companies"
  add_foreign_key "job_applications", "users"
  add_foreign_key "profiles", "users"
end
