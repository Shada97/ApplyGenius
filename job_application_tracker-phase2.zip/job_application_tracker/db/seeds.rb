# Clear old demo data in safe order
ApplicationSkill.destroy_all
Interview.destroy_all
JobApplication.destroy_all
Skill.destroy_all
Company.destroy_all
Profile.destroy_all
User.destroy_all

# -----------------------------
# USERS
# -----------------------------
user1 = User.create!(
  email: "test1@applygenius.com",
  password: "123456"
)

user2 = User.create!(
  email: "test2@applygenius.com",
  password: "123456"
)

# -----------------------------
# PROFILES
# -----------------------------
user1.create_profile!(
  full_name: "Alice Johnson",
  resume: "Experienced data analyst with Python, SQL, and Tableau background.",
  linkedin: "https://linkedin.com/in/alicejohnson"
)

user2.create_profile!(
  full_name: "David Chen",
  resume: "Software engineering student with backend and machine learning experience.",
  linkedin: "https://linkedin.com/in/davidchen"
)

# -----------------------------
# SKILLS
# -----------------------------
python = Skill.create!(name: "Python")
sql = Skill.create!(name: "SQL")
rails = Skill.create!(name: "Ruby on Rails")
aws = Skill.create!(name: "AWS")
ml = Skill.create!(name: "Machine Learning")
api_design = Skill.create!(name: "API Design")

# -----------------------------
# COMPANIES FOR USER 1
# -----------------------------
google = user1.companies.create!(
  company_name: "Google",
  industry: "Technology",
  location: "Toronto",
  website: "https://www.google.com"
)

shopify = user1.companies.create!(
  company_name: "Shopify",
  industry: "E-commerce",
  location: "Ottawa",
  website: "https://www.shopify.com"
)

td = user1.companies.create!(
  company_name: "TD Bank",
  industry: "Banking",
  location: "Toronto",
  website: "https://www.td.com"
)

# -----------------------------
# COMPANIES FOR USER 2
# -----------------------------
amazon = user2.companies.create!(
  company_name: "Amazon",
  industry: "Technology",
  location: "Vancouver",
  website: "https://www.amazon.com"
)

microsoft = user2.companies.create!(
  company_name: "Microsoft",
  industry: "Technology",
  location: "Seattle",
  website: "https://www.microsoft.com"
)

# -----------------------------
# JOB APPLICATIONS FOR USER 1
# -----------------------------
ja1 = user1.job_applications.create!(
  job_title: "Data Analyst",
  status: "In Progress",
  application_date: Date.new(2026, 3, 25),
  company: google
)

ja2 = user1.job_applications.create!(
  job_title: "Backend Engineer",
  status: "Interviewing",
  application_date: Date.new(2026, 3, 20),
  company: shopify
)

ja3 = user1.job_applications.create!(
  job_title: "Data Engineer",
  status: "Rejected",
  application_date: Date.new(2026, 3, 9),
  company: td
)

# -----------------------------
# JOB APPLICATIONS FOR USER 2
# -----------------------------
ja4 = user2.job_applications.create!(
  job_title: "Software Engineer",
  status: "Applied",
  application_date: Date.new(2026, 3, 18),
  company: amazon
)

ja5 = user2.job_applications.create!(
  job_title: "Machine Learning Intern",
  status: "In Progress",
  application_date: Date.new(2026, 3, 22),
  company: microsoft
)

# -----------------------------
# INTERVIEWS
# -----------------------------
ja1.interviews.create!(
  interview_date: Date.new(2026, 3, 27),
  interview_type: "Online",
  notes: "Good discussion on SQL, dashboards, and data cleaning."
)

ja2.interviews.create!(
  interview_date: Date.new(2026, 3, 28),
  interview_type: "Technical",
  notes: "Need stronger preparation on system design and API architecture."
)

ja2.interviews.create!(
  interview_date: Date.new(2026, 4, 2),
  interview_type: "Managerial",
  notes: "Focus on communication, teamwork, and ownership examples."
)

ja5.interviews.create!(
  interview_date: Date.new(2026, 3, 30),
  interview_type: "HR Screen",
  notes: "Initial screening went well. Next round may focus on ML fundamentals."
)

# -----------------------------
# APPLICATION SKILLS
# -----------------------------
ja1.skills << python
ja1.skills << sql

ja2.skills << rails
ja2.skills << api_design
ja2.skills << aws

ja3.skills << python
ja3.skills << sql
ja3.skills << aws

ja4.skills << rails
ja4.skills << aws

ja5.skills << python
ja5.skills << ml

puts "Seed completed successfully."
puts "Test account 1: test1@applygenius.com / 123456"
puts "Test account 2: test2@applygenius.com / 123456"