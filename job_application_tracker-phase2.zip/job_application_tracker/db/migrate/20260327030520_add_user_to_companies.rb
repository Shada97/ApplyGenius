class AddUserToCompanies < ActiveRecord::Migration[8.1]
  def change
    add_reference :companies, :user, foreign_key: true
  end
end