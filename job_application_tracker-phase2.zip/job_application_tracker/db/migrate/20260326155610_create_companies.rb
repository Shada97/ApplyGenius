class CreateCompanies < ActiveRecord::Migration[8.1]
  def change
    create_table :companies do |t|
      t.string :company_name
      t.string :industry
      t.string :location
      t.string :website

      t.timestamps
    end
  end
end
