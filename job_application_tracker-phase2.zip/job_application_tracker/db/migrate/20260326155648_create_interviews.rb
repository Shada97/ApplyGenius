class CreateInterviews < ActiveRecord::Migration[8.1]
  def change
    create_table :interviews do |t|
      t.date :interview_date
      t.string :interview_type
      t.text :notes
      t.references :job_application, null: false, foreign_key: true

      t.timestamps
    end
  end
end
