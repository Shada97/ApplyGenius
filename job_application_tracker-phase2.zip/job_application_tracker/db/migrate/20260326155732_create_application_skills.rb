class CreateApplicationSkills < ActiveRecord::Migration[8.1]
  def change
    create_table :application_skills do |t|
      t.references :job_application, null: false, foreign_key: true
      t.references :skill, null: false, foreign_key: true

      t.timestamps
    end
  end
end
