Rails.application.routes.draw do
  devise_for :users

  get "pages/home"
  root "pages#home"

  resource :profile, only: [:show, :new, :create, :edit, :update]
  resources :companies
  resources :skills

  resources :job_applications do
    resources :interviews
  end

  namespace :api do
    namespace :v1 do
      post "signup", to: "auth#signup"
      post "login", to: "auth#login"

      resources :companies, only: [:index, :show, :create]
      resources :job_applications, only: [:index, :show, :create]
      resources :interviews, only: [:index, :show, :create]
    end
  end
  get "ai", to: "ai#new"
  post "ai/analyze", to: "ai#analyze", as: "ai_analyze"
end