class Skill < ApplicationRecord
  has_many :application_skills, dependent: :destroy
  has_many :job_applications, through: :application_skills

  validates :name, presence: true, uniqueness: true
end