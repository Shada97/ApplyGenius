class User < ApplicationRecord
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  has_one :profile, dependent: :destroy
  has_many :job_applications, dependent: :destroy
  has_many :companies, dependent: :destroy

  before_create :generate_authentication_token

  private

  def generate_authentication_token
    self.authentication_token = loop do
      token = SecureRandom.hex(20)
      break token unless User.exists?(authentication_token: token)
    end
  end
end