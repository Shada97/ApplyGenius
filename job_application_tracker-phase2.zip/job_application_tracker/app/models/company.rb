class Company < ApplicationRecord
  belongs_to :user
  has_many :job_applications, dependent: :destroy

  validates :company_name, presence: true
end