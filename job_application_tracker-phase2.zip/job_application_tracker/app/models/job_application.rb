class JobApplication < ApplicationRecord
  belongs_to :user
  belongs_to :company

  has_many :interviews, dependent: :destroy
  has_many :application_skills, dependent: :destroy
  has_many :skills, through: :application_skills

  validates :job_title, presence: true
  validates :status, presence: true
end