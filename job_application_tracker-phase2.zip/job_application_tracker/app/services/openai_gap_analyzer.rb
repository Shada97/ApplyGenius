require "openai"
require "json"

class OpenaiGapAnalyzer
  def initialize(resume_text:, job_description:)
    @resume_text = resume_text.to_s
    @job_description = job_description.to_s
    @client = OpenAI::Client.new(access_token: ENV["OPENAI_API_KEY"])
  end

  def call
    response = @client.chat(
      parameters: {
        model: "gpt-4.1",
        temperature: 0.2,
        messages: [
          {
            role: "system",
            content: <<~TXT
              You are an AI resume analyzer.

              Compare the resume with the job description and return ONLY valid JSON.

              Format:
              {
                "score": number,
                "strengths": ["..."],
                "gaps": ["..."],
                "suggestions": ["..."]
              }

              Rules:
              - Score must be between 0 and 100
              - Strengths: 4 to 6 items
              - Gaps: 3 to 5 items
              - Suggestions: 3 to 5 items
              - Each item must be concise and no more than one sentence
              - Do not include markdown
              - Do not include explanations outside the JSON
            TXT
          },
          {
            role: "user",
            content: <<~TXT
              Resume:
              #{@resume_text}

              Job Description:
              #{@job_description}
            TXT
          }
        ]
      }
    )

    content = response.dig("choices", 0, "message", "content").to_s

    cleaned = content.strip
    cleaned = cleaned.gsub(/```json/i, "").gsub(/```/, "").strip

    parsed = JSON.parse(cleaned)

    {
      score: parsed["score"] || 0,
      strengths: parsed["strengths"] || [],
      gaps: parsed["gaps"] || [],
      suggestions: parsed["suggestions"] || []
    }
  rescue JSON::ParserError => e
    Rails.logger.error("JSON parse error: #{e.message}")

    {
      score: 0,
      strengths: ["Could not parse AI response"],
      gaps: ["The response format was invalid"],
      suggestions: ["Try again with a shorter resume or job description"]
    }
  rescue => e
    Rails.logger.error("OpenAI error: #{e.message}")

    {
      score: 0,
      strengths: ["AI analysis failed"],
      gaps: ["Could not process request"],
      suggestions: ["Check API key, credits, model access, or logs"]
    }
  end
end