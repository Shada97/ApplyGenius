class ProfilesController < ApplicationController
  before_action :authenticate_user!  
  before_action :authenticate_user!
  before_action :set_profile, only: [:show, :edit, :update]

  def show
  end

  def new
    if current_user.profile.present?
      redirect_to profile_path, notice: "Profile already exists."
    else
      @profile = current_user.build_profile
    end
  end

  def create
    @profile = current_user.build_profile(profile_params)

    if @profile.save
      redirect_to job_applications_path, notice: "Profile created successfully."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def edit
  end

  def update
    if @profile.update(profile_params)
      redirect_to profile_path, notice: "Profile updated successfully."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  private

  def set_profile
    @profile = current_user.profile
    redirect_to new_profile_path, alert: "Please create your profile first." unless @profile
  end

  def profile_params
    params.require(:profile).permit(:full_name, :linkedin, :resume)
  end
end