class SkillsController < ApplicationController
end