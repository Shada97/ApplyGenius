#Phase1
# class JobApplicationsController < ApplicationController
#   before_action :require_login
#   before_action :set_job_application, only: [:show, :edit, :update, :destroy]
#   before_action :authorize_job_application, only: [:show, :edit, :update, :destroy]

#   def index
#     @job_applications = current_user.job_applications.includes(:company, :interviews)
#     @applications_count = @job_applications.count
#     @interviews_count = @job_applications.sum { |application| application.interviews.size }
#     @companies_count = current_user.companies.count
#   end

#   def show
#   end

#   def new
#     @job_application = JobApplication.new
#   end

#   def create
#     @job_application = current_user.job_applications.new(job_application_params)

#     if params[:create_new_company] == "1"
#       company = current_user.companies.new(
#         company_name: params[:new_company_name],
#         industry: params[:new_company_industry],
#         location: params[:new_company_location],
#         website: params[:new_company_website]
#       )

#       if company.company_name.blank?
#         @job_application.errors.add(:company, "name is required when creating a new company")
#         render :new, status: :unprocessable_entity
#         return
#       end

#       unless company.save
#         company.errors.full_messages.each do |msg|
#           @job_application.errors.add(:company, msg)
#         end
#         render :new, status: :unprocessable_entity
#         return
#       end

#       @job_application.company = company
#     end

#     if @job_application.company.nil? && params[:create_new_company] != "1"
#       @job_application.errors.add(:company, "must be selected or created")
#       render :new, status: :unprocessable_entity
#       return
#     end

#     if @job_application.save
#       assign_skills_from_input(@job_application)
#       redirect_to @job_application, notice: "Job application created successfully."
#     else
#       render :new, status: :unprocessable_entity
#     end
#   end

#   def edit
#   end

#   def update
#     if params[:create_new_company] == "1"
#       company = current_user.companies.new(
#         company_name: params[:new_company_name],
#         industry: params[:new_company_industry],
#         location: params[:new_company_location],
#         website: params[:new_company_website]
#       )

#       if company.company_name.blank?
#         @job_application.errors.add(:company, "name is required when creating a new company")
#         render :edit, status: :unprocessable_entity
#         return
#       end

#       unless company.save
#         company.errors.full_messages.each do |msg|
#           @job_application.errors.add(:company, msg)
#         end
#         render :edit, status: :unprocessable_entity
#         return
#       end

#       @job_application.company = company
#     end

#     if @job_application.company.nil? &&
#        job_application_params[:company_id].blank? &&
#        params[:create_new_company] != "1"

#       @job_application.errors.add(:company, "must be selected or created")
#       render :edit, status: :unprocessable_entity
#       return
#     end

#     if @job_application.update(job_application_params)
#       assign_skills_from_input(@job_application)
#       redirect_to @job_application, notice: "Job application updated successfully."
#     else
#       render :edit, status: :unprocessable_entity
#     end
#   end

#   def destroy
#     @job_application.destroy
#     redirect_to job_applications_path, notice: "Job application deleted successfully."
#   end

#   private

#   def set_job_application
#     @job_application = JobApplication.find(params[:id])
#   end

#   def authorize_job_application
#     unless @job_application.user == current_user
#       redirect_to job_applications_path, alert: "Not authorized."
#     end
#   end

#   def job_application_params
#     params.require(:job_application).permit(
#       :job_title,
#       :application_date,
#       :status,
#       :company_id
#     )
#   end

#   def assign_skills_from_input(job_application)
#     return unless params[:skill_names].present?

#     skill_names = params[:skill_names]
#                     .split(",")
#                     .map(&:strip)
#                     .reject(&:blank?)
#                     .uniq

#     skills = skill_names.map do |name|
#       Skill.find_or_create_by(name: name)
#     end

#     job_application.skills = skills
#   end
# end

#Phase2
class JobApplicationsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_job_application, only: [:show, :edit, :update, :destroy]
  before_action :authorize_job_application, only: [:show, :edit, :update, :destroy]

  def index
    @job_applications = current_user.job_applications.includes(:company, :interviews)
    @applications_count = @job_applications.count
    @interviews_count = @job_applications.sum { |application| application.interviews.size }
    @companies_count = current_user.companies.count
  end

  def show
  end

  def new
    @job_application = JobApplication.new
  end

  def create
    @job_application = current_user.job_applications.new(job_application_params)

    if params[:create_new_company] == "1"
      company = current_user.companies.new(
        company_name: params[:new_company_name],
        industry: params[:new_company_industry],
        location: params[:new_company_location],
        website: params[:new_company_website]
      )

      if company.company_name.blank?
        @job_application.errors.add(:company, "name is required when creating a new company")
        render :new, status: :unprocessable_entity
        return
      end

      unless company.save
        company.errors.full_messages.each do |msg|
          @job_application.errors.add(:company, msg)
        end
        render :new, status: :unprocessable_entity
        return
      end

      @job_application.company = company
    end

    if @job_application.company.nil? && params[:create_new_company] != "1"
      @job_application.errors.add(:company, "must be selected or created")
      render :new, status: :unprocessable_entity
      return
    end

    if @job_application.save
      assign_skills_from_input(@job_application)
      redirect_to @job_application, notice: "Job application created successfully."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def edit
  end

  def update
    if params[:create_new_company] == "1"
      company = current_user.companies.new(
        company_name: params[:new_company_name],
        industry: params[:new_company_industry],
        location: params[:new_company_location],
        website: params[:new_company_website]
      )

      if company.company_name.blank?
        @job_application.errors.add(:company, "name is required when creating a new company")
        render :edit, status: :unprocessable_entity
        return
      end

      unless company.save
        company.errors.full_messages.each do |msg|
          @job_application.errors.add(:company, msg)
        end
        render :edit, status: :unprocessable_entity
        return
      end

      @job_application.company = company
    end

    if @job_application.company.nil? &&
       job_application_params[:company_id].blank? &&
       params[:create_new_company] != "1"
      @job_application.errors.add(:company, "must be selected or created")
      render :edit, status: :unprocessable_entity
      return
    end

    if @job_application.update(job_application_params)
      assign_skills_from_input(@job_application)
      redirect_to @job_application, notice: "Job application updated successfully."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @job_application.destroy
    redirect_to job_applications_path, notice: "Job application deleted successfully."
  end

  private

  def set_job_application
    @job_application = JobApplication.find(params[:id])
  end

  def authorize_job_application
    unless @job_application.user == current_user
      redirect_to job_applications_path, alert: "Not authorized."
    end
  end

  def job_application_params
    params.require(:job_application).permit(
      :job_title,
      :application_date,
      :status,
      :company_id
    )
  end

  def assign_skills_from_input(job_application)
    return unless params[:skill_names].present?

    skill_names = params[:skill_names]
                    .split(",")
                    .map(&:strip)
                    .reject(&:blank?)
                    .uniq

    skills = skill_names.map do |name|
      Skill.find_or_create_by(name: name)
    end

    job_application.skills = skills
  end
end