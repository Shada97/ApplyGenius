# class CompaniesController < ApplicationController
#   before_action :require_login
#   before_action :set_company, only: [:show, :edit, :update, :destroy]

#   def index
#     @companies = Company.all
#   end

#   def show
#   end

#   def new
#     @company = Company.new
#   end

#   def create
#     @company = Company.new(company_params)

#     if @company.save
#       redirect_to companies_path, notice: "Company created successfully."
#     else
#       render :new, status: :unprocessable_entity
#     end
#   end

#   def edit
#   end

#   def update
#     if @company.update(company_params)
#       redirect_to company_path(@company), notice: "Company updated successfully."
#     else
#       render :edit, status: :unprocessable_entity
#     end
#   end

#   def destroy
#     @company.destroy
#     redirect_to companies_path, notice: "Company deleted successfully."
#   end

#   private

#   def set_company
#     @company = Company.find(params[:id])
#   end

#   def company_params
#     params.require(:company).permit(:company_name, :industry, :location, :website)
#   end
# end


# Phase 2 changes

class CompaniesController < ApplicationController
  before_action :authenticate_user!
  before_action :set_company, only: [:show, :edit, :update, :destroy]

  def index
    @companies = current_user.companies
  end

  def show
  end

  def new
    @company = current_user.companies.new
  end

  def create
    @company = current_user.companies.new(company_params)

    if @company.save
      redirect_to companies_path, notice: "Company created successfully."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def edit
  end

  def update
    if @company.update(company_params)
      redirect_to company_path(@company), notice: "Company updated successfully."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @company.destroy
    redirect_to companies_path, notice: "Company deleted successfully."
  end

  private

  def set_company
    @company = current_user.companies.find(params[:id])
  end

  def company_params
    params.require(:company).permit(:company_name, :industry, :location, :website)
  end
end