class ApplicationController < ActionController::Base
  before_action :ensure_profile_completed, if: :user_signed_in?

  def after_sign_in_path_for(resource)
    job_applications_path
  end

  def after_sign_up_path_for(resource)
    new_profile_path
  end

  private

  def ensure_profile_completed
    return if devise_controller?
    return if controller_name == "profiles"

    unless current_user.profile.present?
      redirect_to new_profile_path, alert: "Please complete your profile first."
    end
  end
end