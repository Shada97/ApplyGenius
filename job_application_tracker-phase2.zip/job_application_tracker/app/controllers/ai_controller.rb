class AiController < ApplicationController
  def new
  end

  def analyze
    resume_file = params[:resume]
    job_description = params[:job_description]

    resume_text = extract_text_from_pdf(resume_file)

    @result = OpenaiGapAnalyzer.new(
      resume_text: resume_text,
      job_description: job_description
    ).call
  end

  private

  def extract_text_from_pdf(file)
    return "No resume uploaded" unless file

    require "pdf-reader"

    reader = PDF::Reader.new(file.path)
    text = ""

    reader.pages.each do |page|
      text += page.text
    end

    text
  rescue => e
    Rails.logger.error("PDF extraction error: #{e.message}")
    "Could not read PDF"
  end
end