# class InterviewsController < ApplicationController
#   before_action :require_login
#   before_action :set_job_application
#   before_action :set_interview, only: [:edit, :update, :destroy]

#   def new
#     @interview = @job_application.interviews.new
#   end

#   def create
#     @interview = @job_application.interviews.new(interview_params)

#     if @interview.save
#       redirect_to job_application_path(@job_application), notice: "Interview added successfully."
#     else
#       render :new, status: :unprocessable_entity
#     end
#   end

#   def edit
#   end

#   def update
#     if @interview.update(interview_params)
#       redirect_to job_application_path(@job_application), notice: "Interview updated successfully."
#     else
#       render :edit, status: :unprocessable_entity
#     end
#   end

#   def destroy
#     @interview.destroy
#     redirect_to job_application_path(@job_application), notice: "Interview deleted successfully."
#   end

#   private

#   def set_job_application
#     @job_application = JobApplication.find(params[:job_application_id])
#     redirect_to job_applications_path, alert: "Not authorized." unless @job_application.user == current_user
#   end

#   def set_interview
#     @interview = @job_application.interviews.find(params[:id])
#   end

#   def interview_params
#     params.require(:interview).permit(:interview_date, :interview_type, :notes)
#   end
# end


# Phase 2 changes:

class InterviewsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_job_application
  before_action :set_interview, only: [:edit, :update, :destroy]

  def new
    @interview = @job_application.interviews.new
  end

  def create
    @interview = @job_application.interviews.new(interview_params)

    if @interview.save
      redirect_to job_application_path(@job_application), notice: "Interview added successfully."
    else
      render :new, status: :unprocessable_entity
    end
  end

  def edit
  end

  def update
    if @interview.update(interview_params)
      redirect_to job_application_path(@job_application), notice: "Interview updated successfully."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @interview.destroy
    redirect_to job_application_path(@job_application), notice: "Interview deleted successfully."
  end

  private

  def set_job_application
    @job_application = JobApplication.find(params[:job_application_id])
    redirect_to job_applications_path, alert: "Not authorized." unless @job_application.user == current_user
  end

  def set_interview
    @interview = @job_application.interviews.find(params[:id])
  end

  def interview_params
    params.require(:interview).permit(:interview_date, :interview_type, :notes)
  end
end