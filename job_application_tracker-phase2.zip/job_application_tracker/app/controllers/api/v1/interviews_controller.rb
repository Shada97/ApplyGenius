module Api
  module V1
    class InterviewsController < BaseController
      def index
        interviews = Interview.joins(:job_application)
                              .where(job_applications: { user_id: current_api_user.id })

        render json: interviews
      end

      def show
        interview = Interview.joins(:job_application)
                             .where(job_applications: { user_id: current_api_user.id })
                             .find(params[:id])

        render json: interview
      rescue ActiveRecord::RecordNotFound
        render json: { error: "Interview not found" }, status: :not_found
      end

      def create
        job_application = current_api_user.job_applications.find(params[:job_application_id])
        interview = job_application.interviews.new(interview_params)

        if interview.save
          render json: interview, status: :created
        else
          render json: { errors: interview.errors.full_messages }, status: :unprocessable_entity
        end
      rescue ActiveRecord::RecordNotFound
        render json: { error: "Job application not found" }, status: :not_found
      end

      private

      def interview_params
        params.require(:interview).permit(:interview_date, :interview_type, :notes)
      end
    end
  end
end