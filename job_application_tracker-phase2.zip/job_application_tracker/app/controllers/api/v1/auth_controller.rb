module Api
  module V1
    class AuthController < ActionController::API
      def signup
        user = User.new(user_params)

        if user.save
          render json: {
            message: "User created successfully",
            user: {
              id: user.id,
              email: user.email,
              authentication_token: user.authentication_token
            }
          }, status: :created
        else
          render json: { errors: user.errors.full_messages }, status: :unprocessable_entity
        end
      end

      def login
        user = User.find_by(email: params[:email])

        if user&.valid_password?(params[:password])
          render json: {
            message: "Login successful",
            user: {
              id: user.id,
              email: user.email,
              authentication_token: user.authentication_token
            }
          }, status: :ok
        else
          render json: { error: "Invalid email or password" }, status: :unauthorized
        end
      end

      private

      def user_params
        params.permit(:email, :password, :password_confirmation)
      end
    end
  end
end