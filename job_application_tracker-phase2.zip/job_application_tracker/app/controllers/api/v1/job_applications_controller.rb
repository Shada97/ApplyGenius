module Api
  module V1
    class JobApplicationsController < BaseController
      def index
        job_applications = current_api_user.job_applications.includes(:company, :skills, :interviews)

        render json: job_applications.as_json(
          include: {
            company: {},
            skills: {},
            interviews: {}
          }
        )
      end

      def show
        job_application = current_api_user.job_applications.includes(:company, :skills, :interviews).find(params[:id])

        render json: job_application.as_json(
          include: {
            company: {},
            skills: {},
            interviews: {}
          }
        )
      rescue ActiveRecord::RecordNotFound
        render json: { error: "Job application not found" }, status: :not_found
      end

      def create
        job_application = current_api_user.job_applications.new(job_application_params)

        if job_application.save
          render json: job_application, status: :created
        else
          render json: { errors: job_application.errors.full_messages }, status: :unprocessable_entity
        end
      end

      private

      def job_application_params
        params.require(:job_application).permit(:job_title, :application_date, :status, :company_id)
      end
    end
  end
end