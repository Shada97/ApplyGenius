module Api
  module V1
    class CompaniesController < BaseController
      def index
        render json: current_api_user.companies
      end

      def show
        company = current_api_user.companies.find(params[:id])
        render json: company
      rescue ActiveRecord::RecordNotFound
        render json: { error: "Company not found" }, status: :not_found
      end

      def create
        company = current_api_user.companies.new(company_params)

        if company.save
          render json: company, status: :created
        else
          render json: { errors: company.errors.full_messages }, status: :unprocessable_entity
        end
      end

      private

      def company_params
        params.require(:company).permit(:company_name, :industry, :location, :website)
      end
    end
  end
end